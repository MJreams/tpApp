<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"/home/thinkphp/public/../noPhone/login/view/teacherlogincontroller/login.html";i:1549947895;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf8">
    <script src="/static/js/jquery-3.3.1.min.js"></script>
</head>
<body>
    <p>ddd</p>
    <form action="" method="post" id="myform">
        <p>账号：<input name="username" type="text" id="username"></p>
        <p>密码：<input name="password" type="password" id="password"></p>
        <button onclick="ajaxPost()">提交</button>
    </form>
    <script>

        function ajaxPost(){
            var username = $("#username").val();
            var password = $("#password").val();
            var data = {username:username,password:password};
            //serialize() 方法通过序列化表单值，创建 URL 编码文本字符串,这个是jquery提供的方法
            //alert(data);
            $.ajax({

                type:"post",
                url:"Teacherlogin",
                data:data,//这里data传递过去的是序列化以后的字符串
                success:function(data){
                    alert("ajax post success");
                    //$("#content").append(data);//获取成功以后输出返回值
                }
            });
        }

    </script>

</body>
</html>